# Python-Based Forensic Data Cleaning and Outlier Removal

A small, reproducible project demonstrating data cleaning with **Python, Pandas, and NumPy** using a synthetic forensic dataset.

## Project structure

```text
forensic-data-cleaning/
├── data/
│   └── mock_forensic_data.csv
├── notebooks/
│   └── forensic_data_cleaning.ipynb
├── outputs/
│   ├── cleaned_forensic_data.csv
│   ├── cleaning_audit_log.csv
│   ├── excluded_outliers.csv
│   ├── outlier_report.csv
│   └── summary.json
├── src/
│   └── clean_forensic_data.py
├── requirements.txt
└── README.md
```

## What the project does

1. Loads a CSV dataset using Pandas.
2. Inspects missing values and data types.
3. Converts invalid numeric entries and values outside defined domain ranges to missing values.
4. Imputes numeric fields with the median and categorical fields with the mode.
5. Detects statistical outliers using the IQR rule (1.5 × IQR).
6. Exports a cleaned analysis dataset, excluded rows, outlier report, audit log, and JSON summary.

## Setup

Python 3.9+ is recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Run the script

Run from the repository root:

```bash
python src/clean_forensic_data.py
```

Optional paths:

```bash
python src/clean_forensic_data.py --input data/mock_forensic_data.csv --output-dir outputs
```

## Run the notebook

```bash
jupyter notebook notebooks/forensic_data_cleaning.ipynb
```

Run all cells from top to bottom.

## Methodology and limitations

- Numeric missing values: median imputation.
- Categorical missing values: mode imputation.
- Outliers: values outside Q1 − 1.5×IQR and Q3 + 1.5×IQR.
- A row is excluded from the derived analysis dataset if any selected numeric column flags it as an outlier.
- The IQR rule is a statistical screening technique, not proof that a value is erroneous. Review excluded rows in context.
- The supplied data is entirely synthetic and must not be represented as real case evidence.

## Forensic integrity

Never modify original evidence or overwrite source data. Preserve source files, document every transformation, retain excluded records, and use hashes/access controls and validated chain-of-custody procedures in any real forensic workflow. This educational example is not a validated forensic tool.

## Reproducibility

The script and notebook implement the same workflow. Outputs are generated under `outputs/`. The sample outputs are included so the repository can be reviewed without running the code first.
