"""
Forensic data cleaning demonstration.
IMPORTANT: This is a mock dataset. Never overwrite original forensic evidence.
All cleaning decisions are logged; IQR outlier rows are excluded only from the
derived analysis dataset, while the raw input remains unchanged.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd

NUMERIC_COLUMNS = ["collection_days", "file_size_mb", "integrity_score"]
CATEGORICAL_COLUMNS = ["evidence_type", "examiner"]
VALID_RANGES = {
    "collection_days": (0, 365),
    "file_size_mb": (0, 100000),
    "integrity_score": (0, 100),
}

def clean_dataset(input_path, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(input_path)
    original_rows = len(df)
    audit = []

    # Convert invalid numeric values and values outside domain constraints to NaN.
    for col in NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        low, high = VALID_RANGES[col]
        invalid = df[col].notna() & ~df[col].between(low, high)
        for idx in df.index[invalid]:
            audit.append({"row_index": int(idx), "column": col,
                          "action": "invalid_value_to_missing",
                          "original_value": str(df.at[idx, col])})
        df.loc[invalid, col] = np.nan

    # Impute numeric columns with the median; categorical columns with the mode.
    for col in NUMERIC_COLUMNS:
        missing = int(df[col].isna().sum())
        if missing:
            median = df[col].median()
            df[col] = df[col].fillna(median)
            audit.append({"row_index": None, "column": col,
                          "action": "median_imputation",
                          "details": f"{missing} missing/invalid value(s); median={median}"})
    for col in CATEGORICAL_COLUMNS:
        missing = int(df[col].isna().sum())
        if missing:
            mode_values = df[col].mode(dropna=True)
            fill_value = mode_values.iloc[0] if not mode_values.empty else "Unknown"
            df[col] = df[col].fillna(fill_value)
            audit.append({"row_index": None, "column": col,
                          "action": "mode_imputation",
                          "details": f"{missing} missing value(s); mode={fill_value}"})

    # IQR outlier detection on numeric columns. Rows outside any column's
    # 1.5*IQR fences are excluded from the derived cleaned dataset.
    outlier_mask = pd.Series(False, index=df.index)
    outlier_details = []
    for col in NUMERIC_COLUMNS:
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        col_mask = (df[col] < lower) | (df[col] > upper)
        for idx in df.index[col_mask]:
            outlier_details.append({"row_index": int(idx), "column": col,
                                    "value": float(df.at[idx, col]),
                                    "lower_fence": float(lower),
                                    "upper_fence": float(upper)})
        outlier_mask |= col_mask

    cleaned = df.loc[~outlier_mask].copy()
    removed = df.loc[outlier_mask].copy()

    cleaned.to_csv(output_dir / "cleaned_forensic_data.csv", index=False)
    removed.to_csv(output_dir / "excluded_outliers.csv", index=False)
    pd.DataFrame(audit).to_csv(output_dir / "cleaning_audit_log.csv", index=False)
    pd.DataFrame(outlier_details).to_csv(output_dir / "outlier_report.csv", index=False)

    summary = {
        "input_rows": original_rows,
        "output_rows": len(cleaned),
        "excluded_rows": len(removed),
        "numeric_imputation": "median",
        "categorical_imputation": "mode",
        "outlier_method": "IQR (1.5 x IQR)",
        "note": "Raw input preserved; excluded rows and audit details exported separately."
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    return summary

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Clean a mock forensic CSV dataset.")
    parser.add_argument("--input", default="data/mock_forensic_data.csv")
    parser.add_argument("--output-dir", default="outputs")
    args = parser.parse_args()
    print(json.dumps(clean_dataset(args.input, args.output_dir), indent=2))
